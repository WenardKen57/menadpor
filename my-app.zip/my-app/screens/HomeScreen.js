import {
  View,
  Text,
  Button,
  StyleSheet,
  SafeAreaView,
  TextInput,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { useEffect, useState } from "react";
import {
  createItem,
  subscribeItems,
  updateItem,
  deleteItem,
} from "../firebase"; // <-- Make sure this is correctly implemented

export default function HomeScreen({ navigation }) {
  const [input, setInput] = useState("");
  const [items, setItems] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");

  // Subscribe to real-time updates from Firestore
  useEffect(() => {
    const unsubscribe = subscribeItems(setItems);
    return () => unsubscribe();
  }, []);

  const add = async () => {
    if (!input.trim()) return;
    await createItem(input.trim());
    setInput("");
  };

  const startEdit = (item) => {
    setEditingId(item.id);
    setEditText(item.text || "");
  };

  const saveEdit = async () => {
    if (!editingId || !editText.trim()) return;
    await updateItem(editingId, { text: editText.trim() });
    setEditingId(null);
    setEditText("");
  };

  const toggleDone = async (item) => {
    await updateItem(item.id, { done: !item.done });
  };

  const remove = async (id) => {
    await deleteItem(id);
  };

  const renderItem = ({ item }) => (
    <View style={styles.row}>
      <TouchableOpacity onPress={() => toggleDone(item)} style={{ flex: 1 }}>
        <Text style={[styles.text, item.done && styles.done]}>
          {item.text || "(untitled)"}
        </Text>
      </TouchableOpacity>
      <Button title="Edit" onPress={() => startEdit(item)} />
      <View style={{ width: 8 }} />
      <Button title="Del" onPress={() => remove(item.id)} />
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.h1}>Simple Firebase CRUD</Text>

      <View style={styles.inputRow}>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder="Add an item..."
          style={styles.input}
        />
        <Button title="Add" onPress={add} />
      </View>

      {editingId && (
        <View style={styles.editCard}>
          <Text style={styles.h2}>Edit Item</Text>
          <TextInput
            value={editText}
            onChangeText={setEditText}
            style={styles.input}
          />
          <View style={styles.actions}>
            <Button title="Save" onPress={saveEdit} />
            <View style={{ width: 8 }} />
            <Button
              title="Cancel"
              onPress={() => {
                setEditingId(null);
                setEditText("");
              }}
            />
          </View>
        </View>
      )}

      <FlatList
        data={items}
        keyExtractor={(i) => i.id}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        renderItem={renderItem}
        ListEmptyComponent={<Text>No items yet</Text>}
        ListHeaderComponent={
          items.length > 0 ? (
            <Text style={{ fontWeight: "bold" }}>Your Items:</Text>
          ) : null
        }
        style={{ marginTop: 8 }}
      />

      <View style={{ marginTop: 16 }}>
        <Button
          title="Go to About"
          onPress={() => navigation.navigate("About")}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, gap: 12 },
  h1: { fontSize: 22, fontWeight: "700" },
  h2: { fontSize: 18, fontWeight: "600" },
  inputRow: { flexDirection: "row", gap: 8, alignItems: "center" },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 10,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 10,
    padding: 12,
  },
  text: { fontSize: 16 },
  done: { textDecorationLine: "line-through", opacity: 0.6 },
  editCard: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 12,
    padding: 12,
    gap: 8,
  },
  actions: { flexDirection: "row", alignItems: "center" },
});

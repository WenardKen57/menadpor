import { initializeApp, getApps } from "firebase/app";

import {
  getFirestore,
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  doc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCNE_8GD0KaES3fo9VILrV_-miA6z92Af0",
  authDomain: "my-app-expo-7927a.firebaseapp.com",
  projectId: "my-app-expo-7927a",
  storageBucket: "my-app-expo-7927a.firebasestorage.app",
  messagingSenderId: "309304886180",
  appId: "1:309304886180:web:85ad3e312177c01b29b731",
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
export const db = getFirestore(app);

const itemsCol = collection(db, "items");

// ✅ Create an item
export async function createItem(text) {
  if (!text?.trim()) return;
  await addDoc(itemsCol, {
    text: text.trim(),
    done: false,
    createdAt: serverTimestamp(),
    createdAtMs: Date.now(),
  });
}

// ✅ Subscribe to real-time updates
export function subscribeItems(cb) {
  const q = query(itemsCol, orderBy("createdAtMs", "desc")); // 🔄 Fixed typo: createAtMs -> createdAtMs
  return onSnapshot(
    q,
    (snap) => {
      const rows = snap.docs.map((d) => ({
        id: d.id,
        ...d.data(), // ❌ FIXED: was calling addDoc() instead of accessing data
      }));
      cb(rows);
    },
    (err) => console.error("subscribeItems error:", err) // ❌ FIXED: was 'arr' instead of 'err'
  );
}

// ✅ Update an item
export async function updateItem(id, data) {
  await updateDoc(doc(db, "items", id), data);
}

// ✅ Delete an item
export async function deleteItem(id) {
  await deleteDoc(doc(db, "items", id)); // ❌ FIXED: was passing string "items, id"
}
